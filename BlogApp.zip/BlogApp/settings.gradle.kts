rootProject.name = "BlogApp"
include(":app")